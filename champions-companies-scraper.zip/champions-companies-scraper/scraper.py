import argparse
import csv
import json
import re
import time
from pathlib import Path
from typing import Any

from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager

BASE_URL = "https://lab24.ilsole24ore.com/leader-crescita"
YEAR_URLS: dict[int, str] = {
    2019: f"{BASE_URL}/2019",
    2020: f"{BASE_URL}/2020",
    2021: f"{BASE_URL}/2021",
    2022: f"{BASE_URL}/2022",
    2023: f"{BASE_URL}/2023",
    2024: f"{BASE_URL}/2024",
    2025: f"{BASE_URL}/2025",
    2026: BASE_URL,
}

EXPECTED_COUNTS: dict[int, int] = {
    2019: 350,
    2020: 400,
    2021: 450,
    2022: 450,
    2023: 500,
    2024: 500,
    2025: 501,
    2026: 500,
}

OUTPUT_ROOT = Path("output")
HTML_TAG_RE = re.compile(r"<[^>]+>")

JS_CLICK_LOAD_MORE = r"""
const normalize = (value) => (value || '').replace(/\s+/g, ' ').trim().toLowerCase();
const nodes = Array.from(document.querySelectorAll('button, a, div[role="button"], div'));
const target = nodes.find((node) => {
  const text = normalize(node.innerText || node.textContent);
  return text.startsWith('carica altri') || text.includes('carica altri risultati');
});
if (!target) {
  return false;
}
target.scrollIntoView({ block: 'center' });
target.click();
return true;
"""

JS_TABLE_ROW_COUNT = r"""
return document.querySelectorAll('#table tbody tr, table tbody tr').length;
"""

JS_EXTRACT_TABLE_ROWS = r"""
function clean(value) {
  return (value || '').replace(/\s+/g, ' ').trim();
}

const table = document.querySelector('#table table') || document.querySelector('table');
if (!table) {
  return [];
}

const rows = [];
for (const tr of table.querySelectorAll('tbody tr')) {
  const cells = Array.from(tr.querySelectorAll('th, td'))
    .map((cell) => clean(cell.innerText))
    .filter((value) => value.length > 0);

  if (!cells.length) {
    continue;
  }

  const link = tr.querySelector('a[href]');
  rows.push({
    pos: cells[0] ?? '',
    azienda: cells[1] ?? '',
    cagr: cells[2] ?? '',
    fatt2014: cells[3] ?? '',
    fatt2017: cells[4] ?? '',
    settore: cells[5] ?? '',
    regione: cells[6] ?? '',
    presenze_totali: cells[7] ?? '',
    url: link ? link.href : (cells[8] ?? ''),
  });
}

return rows;
"""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Scraper classifica Leader della Crescita. "
            "Esegue lo scraping di un solo anno e salva output/<YEAR>/data.csv"
        )
    )
    parser.add_argument("year", nargs="?", type=int, help="Anno classifica (es. 2026)")
    parser.add_argument("--year", dest="year_flag", type=int, help="Anno classifica (es. 2026)")
    args = parser.parse_args()

    if args.year is None and args.year_flag is None:
        parser.error("Specifica un anno con --year YYYY oppure come argomento posizionale.")

    if args.year is not None and args.year_flag is not None and args.year != args.year_flag:
        parser.error("Hai passato due anni diversi tra argomento posizionale e --year.")

    selected_year = args.year_flag if args.year_flag is not None else args.year
    if selected_year not in YEAR_URLS:
        parser.error(f"Anno non supportato: {selected_year}. Valori validi: {sorted(YEAR_URLS)}")

    args.selected_year = selected_year
    return args


def build_driver() -> webdriver.Chrome:
    chrome_options = Options()
    chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--window-size=1600,3000")
    chrome_options.add_argument("--lang=it-IT")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")

    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)
    driver.set_page_load_timeout(60)
    return driver


def clean_value(value: Any) -> str:
    if value is None:
        return ""

    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False)
    else:
        value = str(value)

    value = HTML_TAG_RE.sub("", value)
    return " ".join(value.replace("\xa0", " ").split())


def click_cookie_buttons(driver: webdriver.Chrome) -> None:
    patterns = [
        "Accetta",
        "Accetto",
        "Accept",
        "I agree",
        "Continua",
        "Consenti",
    ]

    for _ in range(3):
        clicked_any = False
        buttons = driver.find_elements(By.XPATH, "//button | //a")

        for button in buttons:
            try:
                text = clean_value(button.text)
                if not text:
                    continue
                if any(pattern.lower() in text.lower() for pattern in patterns):
                    driver.execute_script("arguments[0].click();", button)
                    time.sleep(1)
                    clicked_any = True
                    break
            except Exception:
                continue

        if not clicked_any:
            break


def extract_js_array_literal(source: str, key: str) -> str | None:
    marker = f"{key}:"
    marker_index = source.find(marker)
    if marker_index == -1:
        return None

    start = source.find("[", marker_index)
    if start == -1:
        return None

    depth = 0
    in_string: str | None = None
    escaped = False

    for index in range(start, len(source)):
        ch = source[index]

        if in_string is not None:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == in_string:
                in_string = None
            continue

        if ch in {"'", '"'}:
            in_string = ch
            continue

        if ch == "[":
            depth += 1
            continue

        if ch == "]":
            depth -= 1
            if depth == 0:
                return source[start : index + 1]

    return None


def parse_rows_from_page_source(page_source: str) -> list[dict[str, Any]]:
    literal = extract_js_array_literal(page_source, "righeIni")
    if not literal:
        return []

    try:
        parsed = json.loads(literal)
    except json.JSONDecodeError as exc:
        print(f"[WARN] Parse JSON righeIni fallito: {exc}")
        return []

    rows: list[dict[str, Any]] = []
    for item in parsed:
        if isinstance(item, dict):
            rows.append({k: clean_value(v) for k, v in item.items()})

    return rows


def load_all_rows_with_pagination(driver: webdriver.Chrome, max_clicks: int = 200) -> list[dict[str, Any]]:
    stale_rounds = 0

    for _ in range(max_clicks):
        before = driver.execute_script(JS_TABLE_ROW_COUNT)
        clicked = driver.execute_script(JS_CLICK_LOAD_MORE)

        if not clicked:
            break

        time.sleep(1.0)
        after = driver.execute_script(JS_TABLE_ROW_COUNT)

        if after <= before:
            stale_rounds += 1
            if stale_rounds >= 3:
                break
        else:
            stale_rounds = 0

    rows = driver.execute_script(JS_EXTRACT_TABLE_ROWS)
    out: list[dict[str, Any]] = []
    for row in rows or []:
        if isinstance(row, dict):
            out.append({k: clean_value(v) for k, v in row.items()})
    return out


def sort_key_for_row(row: dict[str, Any]) -> tuple[int, str]:
    pos = clean_value(row.get("pos", ""))
    if pos.isdigit():
        return int(pos), clean_value(row.get("azienda", ""))
    return 10**9, clean_value(row.get("azienda", ""))


def deduplicate_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    unique: dict[tuple[str, str], dict[str, Any]] = {}
    for row in rows:
        key = (clean_value(row.get("pos", "")), clean_value(row.get("azienda", "")))
        if key not in unique:
            unique[key] = row
    return sorted(unique.values(), key=sort_key_for_row)


def scrape_year(year: int) -> list[dict[str, Any]]:
    url = YEAR_URLS[year]
    print(f"\n[INFO] Scraping anno {year} -> {url}")

    driver = build_driver()
    try:
        driver.get(url)
        time.sleep(3)
        click_cookie_buttons(driver)
        time.sleep(1)

        rows = parse_rows_from_page_source(driver.page_source)
        if rows:
            print(f"[INFO] Dataset completo da sorgente pagina: {len(rows)} righe")

        expected = EXPECTED_COUNTS.get(year)
        if not rows or (expected is not None and len(rows) < expected):
            print("[INFO] Avvio fallback con paginazione UI (Carica altri)...")
            paginated_rows = load_all_rows_with_pagination(driver)
            if len(paginated_rows) > len(rows):
                rows = paginated_rows
                print(f"[INFO] Fallback paginazione: {len(rows)} righe")

        rows = deduplicate_rows(rows)

        if expected is not None and len(rows) != expected:
            print(
                f"[WARN] {year}: trovate {len(rows)} righe, attese circa {expected}. "
                "Controlla la pagina/filtri dell'anno selezionato."
            )
        else:
            print(f"[OK] {year}: {len(rows)} righe")

        return rows
    finally:
        driver.quit()


def csv_headers(year: int) -> list[str]:
    return [
        "RANK",
        "AZIENDA",
        "TASSO DI CRESCITA",
        f"RICAVI {year - 5}",
        f"RICAVI {year - 2}",
        "SETTORE",
        "REGIONE",
        "PRESENZE",
        "SITO WEB",
    ]


def row_to_csv(raw_row: dict[str, Any], year: int) -> dict[str, str]:
    return {
        "RANK": clean_value(raw_row.get("pos", "")),
        "AZIENDA": clean_value(raw_row.get("azienda", "")),
        "TASSO DI CRESCITA": clean_value(raw_row.get("cagr", "")),
        f"RICAVI {year - 5}": clean_value(raw_row.get("fatt2014", "")),
        f"RICAVI {year - 2}": clean_value(raw_row.get("fatt2017", "")),
        "SETTORE": clean_value(raw_row.get("settore", "")),
        "REGIONE": clean_value(raw_row.get("regione", "")),
        "PRESENZE": clean_value(raw_row.get("presenze_totali", "")),
        "SITO WEB": clean_value(raw_row.get("url", "")),
    }


def write_year_csv(year: int, rows: list[dict[str, Any]]) -> Path:
    out_dir = OUTPUT_ROOT / str(year)
    out_dir.mkdir(parents=True, exist_ok=True)

    out_path = out_dir / "data.csv"
    headers = csv_headers(year)

    with out_path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=headers)
        writer.writeheader()
        for row in rows:
            writer.writerow(row_to_csv(row, year))

    return out_path


def main(year) -> None:

    try:
        rows = scrape_year(year)
    except TimeoutException:
        raise RuntimeError(f"Timeout durante lo scraping dell'anno {year}.")
    except WebDriverException as exc:
        raise RuntimeError(f"Errore WebDriver durante lo scraping dell'anno {year}: {exc}") from exc

    if not rows:
        raise RuntimeError(f"Nessun dato estratto per l'anno {year}.")

    out_path = write_year_csv(year, rows)
    print(f"\n[OK] CSV salvato in: {out_path}")
    print(f"[OK] Totale righe: {len(rows)}")


if __name__ == "__main__":
    for y in [2019, 2020, 2021, 2022, 2023, 2024, 2025]:
        try:
            main(y)
        except Exception as exc:
            print(f"\n[ERROR] Errore durante lo scraping dell'anno {y}: {exc}")
